<?php

session_start();
error_reporting(0);
include "functions.php";

?>